#!/usr/bin/env node

/*
 * (c) 2020 BlackBerry Limited. All rights reserved.
 */

var path = require('path'),
    fs = require('fs'),
    execSync = require('child_process').execSync,
    shell = require('shelljs');

function iOSHelper(basePluginPath) {
    this.finalGdIOSSDKPath;
    this.finalGdAssetsBundlePath;
    this.basePluginPath = basePluginPath;
}

iOSHelper.prototype = {
    handleGdIOSSDKPassedByUser: function(bbdSDKForiOS) {
        // validate the values if they suppose to be correct
        // we do not need the path to be escaped as Node handles it itself
        var gdIOSSDKPath = bbdSDKForiOS.replace(/\\ /g, ' ');

        // execSync transforms ‘~’ to full path for different cases.
        // Regular expression here is for removing \n or \r that are in the end of string returned
        // by execSync it supports following cases:
        // ~username1/...
        // ~username2/...
        // ~/...
        gdIOSSDKPath = execSync('echo ' + gdIOSSDKPath, { encoding: 'utf-8' }).replace(/[\r\n]/g, '');

        var gdAssetsBundlePath = path.join(gdIOSSDKPath, 'Versions', 'A', 'Resources', 'GDAssets.bundle');
        if (!fs.existsSync(gdIOSSDKPath) || !fs.existsSync(gdAssetsBundlePath)) {
            throw new Error("BlackBerry Dynamics iOS SDK is not available at path you passed: " + gdIOSSDKPath + ". Please enter correct path.");
        } else {
            // remove GD.framework, if it was previosuly copied by expicit mode
            this.removeBasePluginGdFrameworkSetForExpicitMode();

            var gdIOSSDKMode = 'ios',
                xcodeSelectResult = shell.exec('xcode-select -p', { silent: true }).stdout.trim(),
                isDefaultGdIOSSDKPath = gdIOSSDKPath.indexOf(xcodeSelectResult) === 0;

            if (!isDefaultGdIOSSDKPath) {
                gdIOSSDKMode = 'ios-explicit';
                var pathToiOSHooks = path.join(this.basePluginPath, 'scripts', 'hooks', 'ios'),
                    // DEVNOTE: here we need a proper path to Frameworks without "/GD.framework", it is used in addEmbeddedFrameworks.rb
                    gdIOSSDKFrameworksPath = gdIOSSDKPath.substring(0, gdIOSSDKPath.lastIndexOf('/')),
                    replaceGDiOSPath = "GD_IOS_PATH = '" + gdIOSSDKFrameworksPath + "'";

                var replaceGDiOSPathInHook = function(hook) {
                    var hookPath = path.join(pathToiOSHooks, hook),
                        content = fs.readFileSync(hookPath, 'utf-8');

                    fs.writeFileSync(
                        hookPath,
                        content.replace(/(GD_IOS_PATH.+)/, replaceGDiOSPath),
                        {encoding: 'utf-8'}
                    );
                };
                replaceGDiOSPathInHook('basePluginManager.rb');
            }

            this.finalGdIOSSDKPath = gdIOSSDKPath;
            this.finalGdAssetsBundlePath = gdAssetsBundlePath;
            return gdIOSSDKMode;
        }
    },
    generateAutomaticPathToGdIOSSDK: function() {
        // check if user directory is available ("/Users/<user>/") on Mac
        if (!process.env.HOME) {
            throw new Error("Your user directory is not available");
        } else {
            console.log('\n\x1b[32m%s\x1b[0m', 'User path on Mac: ' + process.env.HOME);
        }

        // remove GD.framework, if it was previosuly copied by expicit mode
        this.removeBasePluginGdFrameworkSetForExpicitMode();

        // generate automatic path to BlackBerry Dynamics iOS SDK
        var gdIOSSDKAutomaticPath = path.join(process.env.HOME, 'Library', 'Application Support', 'BlackBerry', 'Good.platform', 'iOS', 'Frameworks', 'GD.framework');
        if (!fs.existsSync(gdIOSSDKAutomaticPath)) {
            process.env.GD_SDK_ERROR_MESSAGE = process.env.GD_SDK_ERROR_MESSAGE +
                "BlackBerry Dynamics iOS SDK is not available at the following path: \n" +
                "\t\"" + gdIOSSDKAutomaticPath + "\"\n";
            return false;
        } else {
            this.finalGdIOSSDKPath = gdIOSSDKAutomaticPath;
        }
        var gdAssetsBundlePath = path.join(this.finalGdIOSSDKPath, 'Versions', 'A', 'Resources', 'GDAssets.bundle');
        if (!fs.existsSync(gdAssetsBundlePath)) {
            throw new Error("GDAssets.bundle is not available at path: " + gdAssetsBundlePath);
        } else {
            this.finalGdAssetsBundlePath = gdAssetsBundlePath;
            return true;
        }
    },
    removeBasePluginGdFrameworkSetForExpicitMode: function() {
        var pathToBasePluginGdFramework = path.join(this.basePluginPath, 'src', 'ios', 'frameworks', 'GD.framework');
        if (fs.existsSync(path.join(pathToBasePluginGdFramework))) {
            shell.exec('rm -rf "' + path.join(pathToBasePluginGdFramework) + '"');
        }
    }
}

exports.iOSHelper = iOSHelper;
