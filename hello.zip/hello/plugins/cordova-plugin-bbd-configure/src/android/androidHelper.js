#!/usr/bin/env node

/*
 * (c) 2019 BlackBerry Limited. All rights reserved.
 */

var path = require('path'),
    fs = require('fs'),
    execSync = require('child_process').execSync,
    os = require('os');

function AndroidHelper(context, basePluginPath) {
    try {
        this.shellJS = require('shelljs');
        this.basePluginPath = basePluginPath;
        this.gradlePropertiesPath = path.join(basePluginPath, 'scripts', 'gradle', 'gradle.properties');
        this.finalGdAndroidSDKPath;
    } catch (e) {
        throw e;
    }
}

AndroidHelper.prototype = {

    handleGdAndroidSDKPassedByUser: function(bbdSDKForAndroid) {
        // validate the values if they suppose to be correct
        // we do not need the path to be escaped as Node handles it itself

        bbdSDKForAndroid = bbdSDKForAndroid.replace(/\\ /g, ' ');

        // execSync transforms ‘~’ to full path for different cases.
        // Regular expression here is for removing \n or \r that are in the end of string returned
        // by execSync it supports following cases:
        // ~username1/...
        // ~username2/...
        // ~/...
        bbdSDKForAndroid = execSync('echo ' + bbdSDKForAndroid, { encoding: 'utf-8' }).replace(/[\r\n]/g, '');

        var m2Path;
        if (path.basename(bbdSDKForAndroid) == 'm2repository') {
            m2Path = bbdSDKForAndroid;
        } else {
            m2Path = path.join(bbdSDKForAndroid, '..', 'm2repository')
        }

        if (fs.existsSync(m2Path)) {
            this.updateGradlePropertiesWithM2Path(m2Path);
            this.finalGdAndroidSDKPath = m2Path;
        } else {
            throw new Error('BlackBerry Dynamics Android SDK is not available at path you passed: ' +
                bbdSDKForAndroid + '. Please enter correct path.');
        }
    },
    generateAutomaticPathToGdAndroidSDK: function(cordovaVersion) {
        var androidSDKPath;

        if (process.env.ANDROID_HOME) {
            console.log('\x1b[32m%s\x1b[0m', '\nANDROID_HOME: ' + process.env.ANDROID_HOME);
        }
        if (process.env.ANDROID_SDK_ROOT) {
            console.log('\x1b[32m%s\x1b[0m', '\nANDROID_SDK_ROOT: ' + process.env.ANDROID_SDK_ROOT);
        }

        if (process.env.ANDROID_HOME) {
            androidSDKPath = process.env.ANDROID_HOME;
            console.warn(
                '\x1b[33m%s\x1b[0m',
                '\nWARNING: ANDROID_HOME variable is deprecated and its support might be removed in future versions.'
            );
        } else if (process.env.ANDROID_SDK_ROOT) {
            androidSDKPath = process.env.ANDROID_SDK_ROOT;
        } else {
            throw new Error('\nERROR: None of ANDROID_HOME & ANDROID_SDK_ROOT environment variables is set.');
        }

        var m2path = path.join(androidSDKPath, 'extras', 'blackberry', 'dynamics_sdk', 'm2repository');

        if (fs.existsSync(m2path)) {
            this.finalGdAndroidSDKPath = m2path;
            return true;
        } else {
            process.env.GD_SDK_ERROR_MESSAGE = process.env.GD_SDK_ERROR_MESSAGE +
                'BlackBerry Dynamics Android SDK is not available at the following path: \n' +
                '\t"' + m2path + '"\n';
            return false;
        }
    },
    updateGradlePropertiesWithM2Path: function(value) {
        var content = fs.readFileSync(this.gradlePropertiesPath, 'utf-8');
        if (content.includes('bbdSdkPath')) {
            content = content.split(os.EOL).filter(function(line) {
                return !line.includes('bbdSdkPath')
            }).join(os.EOL);
        }

        if (process.platform == 'win32') {
            value = value.split('\\').join('\\\\');
        }

        content += os.EOL + 'bbdSdkPath=' + value;

        fs.writeFileSync(this.gradlePropertiesPath, content, 'utf-8');
    }
}

exports.AndroidHelper = AndroidHelper;
