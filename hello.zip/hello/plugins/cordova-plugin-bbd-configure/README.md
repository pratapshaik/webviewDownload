BlackBerry Dynamics Cordova Configure plugin
============================================
> The Configure plugin is a special helper plugin used to configure the
> BlackBerry Dynamics Base plugin.

Location
========
`BlackBerry_Dynamics_SDK_for_Cordova_<version>/plugins/cordova-plugin-bbd-configure`

Usage
=====
See the readme file of the BlackBerry Dynamics Cordova Base plugin for usage
instructions.
