cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-bbd-file.DirectoryEntry",
      "file": "plugins/cordova-plugin-bbd-file/www/DirectoryEntry.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.DirectoryEntry"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.DirectoryReader",
      "file": "plugins/cordova-plugin-bbd-file/www/DirectoryReader.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.DirectoryReader"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.Entry",
      "file": "plugins/cordova-plugin-bbd-file/www/Entry.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.Entry"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.File",
      "file": "plugins/cordova-plugin-bbd-file/www/File.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.File"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileEntry",
      "file": "plugins/cordova-plugin-bbd-file/www/FileEntry.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileEntry"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileError",
      "file": "plugins/cordova-plugin-bbd-file/www/FileError.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileError"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileReader",
      "file": "plugins/cordova-plugin-bbd-file/www/FileReader.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileReader"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileSystem",
      "file": "plugins/cordova-plugin-bbd-file/www/FileSystem.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileSystem"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileUploadOptions",
      "file": "plugins/cordova-plugin-bbd-file/www/FileUploadOptions.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileUploadOptions"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileUploadResult",
      "file": "plugins/cordova-plugin-bbd-file/www/FileUploadResult.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileUploadResult"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.FileWriter",
      "file": "plugins/cordova-plugin-bbd-file/www/FileWriter.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.FileWriter"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.Flags",
      "file": "plugins/cordova-plugin-bbd-file/www/Flags.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.Flags"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.LocalFileSystem",
      "file": "plugins/cordova-plugin-bbd-file/www/LocalFileSystem.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.LocalFileSystem"
      ],
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.Metadata",
      "file": "plugins/cordova-plugin-bbd-file/www/Metadata.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.Metadata"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.ProgressEvent",
      "file": "plugins/cordova-plugin-bbd-file/www/ProgressEvent.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.ProgressEvent"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.fileSystems",
      "file": "plugins/cordova-plugin-bbd-file/www/fileSystems.js",
      "pluginId": "cordova-plugin-bbd-file"
    },
    {
      "id": "cordova-plugin-bbd-file.requestFileSystem",
      "file": "plugins/cordova-plugin-bbd-file/www/requestFileSystem.js",
      "pluginId": "cordova-plugin-bbd-file",
      "clobbers": [
        "window.requestFileSystem"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.resolveLocalFileSystemURI",
      "file": "plugins/cordova-plugin-bbd-file/www/resolveLocalFileSystemURI.js",
      "pluginId": "cordova-plugin-bbd-file",
      "merges": [
        "window"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.exportLogs",
      "file": "plugins/cordova-plugin-bbd-file/www/exportLogs.js",
      "pluginId": "cordova-plugin-bbd-file",
      "merges": [
        "window.FileSystem"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.iosFileSystem",
      "file": "plugins/cordova-plugin-bbd-file/www/ios/FileSystem.js",
      "pluginId": "cordova-plugin-bbd-file",
      "merges": [
        "FileSystem"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file.fileSystems-roots",
      "file": "plugins/cordova-plugin-bbd-file/www/fileSystems-roots.js",
      "pluginId": "cordova-plugin-bbd-file",
      "runs": true
    },
    {
      "id": "cordova-plugin-bbd-file.fileSystemPaths",
      "file": "plugins/cordova-plugin-bbd-file/www/fileSystemPaths.js",
      "pluginId": "cordova-plugin-bbd-file",
      "merges": [
        "cordova"
      ],
      "runs": true
    },
    {
      "id": "cordova-plugin-bbd-file-transfer.FileTransferError",
      "file": "plugins/cordova-plugin-bbd-file-transfer/www/FileTransferError.js",
      "pluginId": "cordova-plugin-bbd-file-transfer",
      "clobbers": [
        "window.FileTransferError"
      ]
    },
    {
      "id": "cordova-plugin-bbd-file-transfer.FileTransfer",
      "file": "plugins/cordova-plugin-bbd-file-transfer/www/FileTransfer.js",
      "pluginId": "cordova-plugin-bbd-file-transfer",
      "clobbers": [
        "window.FileTransfer"
      ]
    },
    {
      "id": "cordova-plugin-bbd-sqlite-storage.SQLitePlugin",
      "file": "plugins/cordova-plugin-bbd-sqlite-storage/www/SQLitePlugin.js",
      "pluginId": "cordova-plugin-bbd-sqlite-storage",
      "clobbers": [
        "window.openDatabase"
      ]
    },
    {
      "id": "cordova-plugin-bbd-sqlite-storage.sqlite3enc_import",
      "file": "plugins/cordova-plugin-bbd-sqlite-storage/www/SQLiteImport.js",
      "pluginId": "cordova-plugin-bbd-sqlite-storage",
      "clobbers": [
        "window.sqlite3enc_import"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-bbd-configure": "1.2.0",
    "cordova-plugin-bbd-file": "1.0.0",
    "cordova-plugin-bbd-file-transfer": "1.0.0",
    "cordova-plugin-bbd-sqlite-storage": "1.0.0"
  };
});